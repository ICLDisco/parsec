/* A Bison parser, made by GNU Bison 3.7.4.  */

/* Skeleton interface for Bison GLR parsers in C

   Copyright (C) 2002-2015, 2018-2020 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_HOME_BOUTEILL_PARSEC_DPLASMA_BUILD_CUDA_PARSEC_CONTRIB_PREGEN_FLEX_BISON_PARSEC_INTERFACES_PTG_PTG_COMPILER_PARSEC_Y_H_INCLUDED
# define YY_YY_HOME_BOUTEILL_PARSEC_DPLASMA_BUILD_CUDA_PARSEC_CONTRIB_PREGEN_FLEX_BISON_PARSEC_INTERFACES_PTG_PTG_COMPILER_PARSEC_Y_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    VAR = 258,                     /* VAR  */
    ASSIGNMENT = 259,              /* ASSIGNMENT  */
    EXTERN_DECL = 260,             /* EXTERN_DECL  */
    COMMA = 261,                   /* COMMA  */
    OPEN_PAR = 262,                /* OPEN_PAR  */
    CLOSE_PAR = 263,               /* CLOSE_PAR  */
    BODY_START = 264,              /* BODY_START  */
    BODY_END = 265,                /* BODY_END  */
    STRING = 266,                  /* STRING  */
    SIMCOST = 267,                 /* SIMCOST  */
    COLON = 268,                   /* COLON  */
    SEMICOLON = 269,               /* SEMICOLON  */
    DEPENDENCY_TYPE = 270,         /* DEPENDENCY_TYPE  */
    ARROW = 271,                   /* ARROW  */
    QUESTION_MARK = 272,           /* QUESTION_MARK  */
    PROPERTIES_ON = 273,           /* PROPERTIES_ON  */
    PROPERTIES_OFF = 274,          /* PROPERTIES_OFF  */
    DATA_NEW = 275,                /* DATA_NEW  */
    DATA_NULL = 276,               /* DATA_NULL  */
    EQUAL = 277,                   /* EQUAL  */
    NOTEQUAL = 278,                /* NOTEQUAL  */
    LESS = 279,                    /* LESS  */
    LEQ = 280,                     /* LEQ  */
    MORE = 281,                    /* MORE  */
    MEQ = 282,                     /* MEQ  */
    AND = 283,                     /* AND  */
    OR = 284,                      /* OR  */
    XOR = 285,                     /* XOR  */
    NOT = 286,                     /* NOT  */
    JDF_INT = 287,                 /* JDF_INT  */
    PLUS = 288,                    /* PLUS  */
    MINUS = 289,                   /* MINUS  */
    TIMES = 290,                   /* TIMES  */
    DIV = 291,                     /* DIV  */
    MODULO = 292,                  /* MODULO  */
    SHL = 293,                     /* SHL  */
    SHR = 294,                     /* SHR  */
    RANGE = 295,                   /* RANGE  */
    OPTION = 296                   /* OPTION  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{

    int                   number;
    char*                 string;
    jdf_expr_operand_t    expr_op;
    jdf_external_entry_t *external_code;
    jdf_global_entry_t   *global;
    jdf_function_entry_t *function;
    jdf_param_list_t     *param_list;
    jdf_def_list_t       *property;
    jdf_name_list_t      *name_list;
    jdf_variable_list_t  *variable_list;
    jdf_dataflow_t       *dataflow;
    jdf_expr_t           *named_expr;
    jdf_dep_t            *dep;
    jdf_dep_flags_t       dep_type;
    jdf_guarded_call_t   *guarded_call;
    jdf_call_t           *call;
    jdf_expr_t           *expr;
    jdf_body_t           *body;


};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif

/* Location type.  */
#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE YYLTYPE;
struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
};
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif


extern YYSTYPE yylval;
extern YYLTYPE yylloc;
int yyparse (void);

#endif /* !YY_YY_HOME_BOUTEILL_PARSEC_DPLASMA_BUILD_CUDA_PARSEC_CONTRIB_PREGEN_FLEX_BISON_PARSEC_INTERFACES_PTG_PTG_COMPILER_PARSEC_Y_H_INCLUDED  */
